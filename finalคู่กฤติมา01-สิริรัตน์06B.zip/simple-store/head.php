<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gan Cream Shop </title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome/css/all.min.css" rel="stylesheet">
<script src="js/jquery.min.js"> </script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>   
      *:not(h6) {
                font-size: 0.93rem;
      }
      
      nav *:not(div.navbar-brand) {
            font-size: 0.90rem !important;
      }

       .nav-link { 
             color: aqua !important; 
       }
       
       .nav-link:hover { 
             color: red !important 
       }
       
      li.active .nav-link { 
            color: magenta !important; 
      }

      a.dropdown-item:hover { 
            color: red; 
      } 

      form *:not(h6) {
            font-size: 0.87rem !important;
      }
</style>
